pyLDLE2
========

pyLDLE2 provides an implementation of our manifold learning algorithm [LDLE](http://jmlr.org/papers/v22/21-0131.html) and several variations of it.


Installation
------------

Install $project by running:

    python3 -m pip install pyLDLE2

Contribute
----------

- Issue Tracker: github.com/chiggum/pyLDLE2/issues
- Source Code: github.com/chiggum/pyLDLE2

Documentation
----------
https://pyldle2.readthedocs.io/en/latest/